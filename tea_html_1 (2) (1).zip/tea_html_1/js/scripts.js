function onMouseOver(x, url) {
    x.src = url;
}

function onMouseOut(x, url) {
	x.src = url;
}

// function onMouseOut(x) {
//     x.style.height = "32px";
//     x.style.width = "32px";
// }